
RF <- function(dados, Y){
  
  # Agrupamento 
  k <- 2  # Número de clusters
  set.seed(100)
  clusters <- kmeans(Y, centers = k, nstart = 25)
  
  # Processamento dos dados
  X1 <- dados
  # Calcular média de Y para cada cluster
  media <- aggregate(Y, by = list(cluster = clusters$cluster), FUN = mean)
  # Identificar qual cluster tem a maior média
  cluster_alta_media <- media$cluster[which.max(media$x)]
  
  # Atribuir 1 para o cluster com alta média, 0 caso contrário
  X1$Produtividade <- ifelse(clusters$cluster == cluster_alta_media, 1, 0)
  
  return(X1)  
}


# pfun final baseada no diagnóstico
pfun <- function(object, newdata) {
  # Converter para data frame
  if (is.matrix(newdata)) {
    newdata <- as.data.frame(newdata)
    colnames(newdata) <- colnames(X)[colnames(X) != "Produtividade"]
  }
  
  # Fazer predição
  pred <- predict(object, data = newdata)
  
  
  if (is.matrix(pred$predictions)) {
    return(as.numeric(pred$predictions[, 1]))
  } else if (length(pred$predictions) == 2 * nrow(newdata)) {
    # Se retornou o dobro de valores, pegar a primeira metade
    n <- nrow(newdata)
    return(as.numeric(pred$predictions[1:n]))
  } else {
    return(as.numeric(pred$predictions))
  }
}



# Função SHAP modificada para múltiplas simulações
simulacao_shap <- function(modelo, X, cultura, sim_vector = c(100, 1000, 2000), 
                           show_x_title = TRUE, tag = NULL, infor = NULL, tags = c("A)", "B)")) {
  
  # Listas para armazenar resultados
  resultados <- list()
  convergence_data <- data.frame()
  
  
  # Loop através do vetor de simulações
  for (i in seq_along(sim_vector)) {
    NumSim <- sim_vector[i]
    set.seed(100)
    
    cat("Executando", NumSim, "simulações SHAP...\n")
    
    # Calcular valores SHAP para esta simulação
    shap <- fastshap::explain(
      modelo,
      X = X[, -which(names(X) == "Produtividade")],  # Remover a variável resposta
      pred_wrapper = pfun,
      nsim = NumSim,  # Número de simulações (valor único)
      parallel = TRUE
    )
    
    # Converter para dataframe se for matriz
    if (is.matrix(shap)) {
      shap_df <- as.data.frame(shap)
    } else {
      shap_df <- shap
    }
    
    # Calcular importância absoluta média (módulo)
    shap_abs <- data.frame(
      Variable = colnames(shap_df),
      Importance = apply(abs(shap_df), 2, mean),
      NumSim = NumSim
    ) %>%
      arrange(desc(Importance))
    
    # Calcular média real dos valores SHAP (com negativos)
    shap_mean <- data.frame(
      Variable = colnames(shap_df),
      Mean_Effect = apply(shap_df, 2, mean),
      NumSim = NumSim
    ) %>%
      arrange(desc(abs(Mean_Effect)))
    
    # Armazenar resultados
    resultados[[paste0("sim_", NumSim)]] <- list(
      absolute_importance = shap_abs,
      mean_effects = shap_mean,
      shap_values = shap_df
    )
    
    # Preparar dados para gráfico de convergência - VALORES REAIS (não absolutos)
    for (var in colnames(shap_df)) {
      convergence_data <- rbind(convergence_data, data.frame(
        Variable = var,
        NumSim = NumSim,
        Mean_Effect = mean(shap_df[[var]]),  # Valor real, não absoluto
        Abs_Effect = mean(abs(shap_df[[var]])),
        stringsAsFactors = FALSE
      ))
    }
  }
  
  # Mapear os nomes das variáveis para os nomes em inglês
  var_names <- c(
    "Tmax" = "Maximum\n Temperature",
    "Tmin" = "Minimum\n Temperature", 
    "Precip" = "Precipitation",
    "m" = "Municipality"
  )
  
  # Aplicar os nomes em inglês aos dados de convergência
  convergence_data$Variable <- factor(convergence_data$Variable,
                                      levels = names(var_names),
                                      labels = var_names)
  
  # Criar gráfico de convergência - GRÁFICO DE DISPERSÃO com valores reais
  convergence_plot <- ggplot(convergence_data, aes(x = NumSim, y = Mean_Effect, color = Variable)) +
    geom_point(size = 3) +
    geom_line(size = 1) +
    geom_text(aes(label = sprintf("%.3f", Mean_Effect)), 
              vjust = -1, size = 3, show.legend = FALSE) +
    scale_x_continuous(breaks = sim_vector) +
    labs(title = paste("Convergência dos valores SHAP\n -", cultura),
         x = "Número de simulações",
         y = "Valor SHAP médio",
         color = "Variável") +
    theme_minimal() +
    theme(plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
          legend.position = "bottom",
          panel.grid.major = element_line(color = "grey90"),
          panel.grid.minor = element_line(color = "grey95"))
  
  # Criar gráficos individuais para a última simulação (maior número)
  ultima_sim <- resultados[[length(resultados)]]
  shap_abs <- ultima_sim$absolute_importance
  shap_mean <- ultima_sim$mean_effects
  
  # Aplicar nomes em inglês
  shap_abs$Variable <- factor(shap_abs$Variable,
                              levels = names(var_names),
                              labels = var_names)
  
  shap_mean$Variable <- factor(shap_mean$Variable,
                               levels = names(var_names),
                               labels = var_names)
  
  # Converter valores absolutos para porcentagens
  total_importance <- sum(shap_abs$Importance)
  shap_abs$Percentage <- (shap_abs$Importance / total_importance) * 100
  
  # Calcular porcentagem para mean effects
  total_abs_effect <- sum(abs(shap_mean$Mean_Effect))
  shap_mean$Percentage <- (abs(shap_mean$Mean_Effect) / total_abs_effect) * 100
  
  # Ajustar o sinal da porcentagem para mean effects
  shap_mean$Percentage <- shap_mean$Percentage * sign(shap_mean$Mean_Effect)
  
  # Criar gráfico de importância absoluta
  plot_abs <- ggplot(shap_abs, aes(x = reorder(Variable, Percentage), y = Percentage)) +
    geom_col(fill = "steelblue", width = 0.7) +
    geom_text(aes(label = sprintf("%.1f%%", Percentage)), 
              hjust = -0.2, size = 3.5, fontface = "bold") +
    coord_flip() +
    scale_y_continuous(limits = c(0, max(shap_abs$Percentage) * 1.1),
                       breaks = seq(0, 100, 10),
                       labels = function(x) paste0(x, "%")) +
    labs(title = paste("Shap average absolute importance\n -", cultura, "(", max(sim_vector), "simulações)"),
         y = "") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
          axis.text.y = element_text(face = "bold", size = 10),
          plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.background = element_blank(),
          axis.line = element_line(color = "black"))
  
  if (!show_x_title) {
    plot_abs <- plot_abs + labs(x = NULL)
  } else {
    plot_abs <- plot_abs + labs(x = "Variables")
  }
  
  # Criar gráfico de média
  max_abs_percentage <- max(abs(shap_mean$Percentage))
  y_limits <- c(-max_abs_percentage * 1.1, max_abs_percentage * 1.1)
  
  plot_mean <- ggplot(shap_mean, aes(x = reorder(Variable, Mean_Effect), y = Percentage)) +
    geom_col(aes(fill = Mean_Effect > 0), width = 0.7) +
    geom_text(aes(label = sprintf("%.1f%%", Percentage)), 
              hjust = ifelse(shap_mean$Percentage > 0, -0.2, 1.2), 
              size = 3.5, fontface = "bold") +
    scale_fill_manual(values = c("TRUE" = "darkgreen", "FALSE" = "red")) +
    coord_flip() +
    scale_y_continuous(limits = y_limits,
                       labels = function(x) paste0(x, "%")) +
    labs(title = paste("Shap average importance\n -", cultura, "(", max(sim_vector), "simulações)"),
         y = "") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
          axis.text.y = element_text(face = "bold", size = 10),
          plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.background = element_blank(),
          axis.line = element_line(color = "black"),
          legend.position = "none")
  
  if (!show_x_title) {
    plot_mean <- plot_mean + labs(x = NULL)
  } else {
    plot_mean <- plot_mean + labs(x = "Variables")
  }
  
  # Adicionar tag se especificada
  if (!is.null(tag)) {
    plot_abs <- plot_abs + labs(tag = tags[1])
    plot_mean <- plot_mean + labs(tag = tags[2])
  }
  
  # Combinar os gráficos
  combined_plot <- gridExtra::grid.arrange(
    plot_abs, 
    plot_mean, 
    ncol = 2
  )
  lista <- list(
    resultados = resultados,
    convergence_data = convergence_data,
    Valrores_shap = shap,
    plots = list(
      absolute = plot_abs,
      mean = plot_mean,
      combined = combined_plot,
      convergence = convergence_plot
    ))
  
  
  # Retornar todos os resultados
  return(lista)
}

################  Grade Hiperparametros e Controle de Treino ##################


funcao_tunagem1 <- function(model){
  ntree_values <- seq(5,150,1)
  max_depth_values <- c(5:50)
  results <- data.frame(ntree = integer(), max_nodes = integer(), accuracy = numeric())
  
  colnames(model$trainingData)[1] <- "Produtividade" 
  
  model$trainingData$m <- as.numeric(model$trainingData$m)
  for (ntree in ntree_values) {
    for (max_nodes in max_depth_values) {
      # Ajustar o modelo com randomForest
      set.seed(100)
      rf_model <- ranger::ranger(
        Produtividade ~ .,
        data = model$trainingData,
        num.trees = ntree,
        mtry = model$bestTune$mtry,
        min.node.size = model$bestTune$min.node.size,
        max.depth = max_nodes,  
        importance = "permutation",
        replace = TRUE,
        classification = TRUE,
        verbose = FALSE
      )
      
      
      
      # Calcular acurácia
      accuracy <- sum(diag(rf_model$confusion.matrix)) / sum(rf_model$confusion.matrix)
      
      # Armazenar resultados
      results <- rbind(results, data.frame(ntree = ntree, max_nodes = max_nodes, accuracy = accuracy))
    }
  }
  return(results)
  
}



ctrl <- trainControl(method = "cv", number = 10, 
                     summaryFunction = multiClassSummary, 
                     verboseIter = FALSE, 
                     allowParallel = TRUE,
                     search = "random")

grid <- expand.grid(
  mtry = c(1:4),
  splitrule = c("gini"),
  min.node.size = c(5:30)
)






















