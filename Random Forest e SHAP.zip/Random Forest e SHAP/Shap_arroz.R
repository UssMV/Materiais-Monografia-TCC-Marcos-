rm(list=ls())

# bibliotecas
library(randomForest)
library(caret)
library(dplyr) 
library(cluster)
library(ggplot2)
library(reshape2)
library(patchwork)
library(fastshap)
source("C:/Users/jacim/Downloads/Funções SHAP e Grid Hiperparametros.R")

# dados de rendimento ajustados sem tendencia tecnologica
local <- "C:/Users/jacim/Downloads/Dados Rdata/Arroz68_RG.RData"
load(local)




############    Periodo 1974 - 1990 ###############################################

# dados dos hiperparametros
l <- "C:/Users/jacim/Downloads/Avaliação com Trend Spline/DADOS SPLINES/M_arroz.RData"
load(l)


X <- RF(dados = df[,-1], Y = df$rendimento_74_90)

X$Produtividade <- factor(X$Produtividade, 
                          levels = c(1, 0), 
                          labels = c("Alta", "Baixa"))


# Ajustandp modelo Random Forest para Classificacao
set.seed(100)
modelo <- ranger::ranger(
  Produtividade ~ .,
  data = X,
  num.trees = Parm$ntree,
  mtry = model$bestTune$mtry,
  min.node.size = model$bestTune$min.node.size,
  max.depth = Parm$max_nodes,  
  importance = "permutation",
  probability = T,
  replace = TRUE,
  classification = TRUE,
  verbose = FALSE
)  


shap_1974_1990 <- simulacao_shap(modelo = modelo, X = X, cultura = "Rice (1974-1990)",
                        show_x_title = FALSE, sim_vector = 2000, tag = TRUE)


#------------------------------------------------------------------------------
##################### Periodo 1991-2019 #######################################


Y <-  df1$rendimento_91_19 
X <- RF(dados = df1[,-1], Y = Y)

X$Produtividade <- factor(X$Produtividade, 
                          levels = c(1, 0), 
                          labels = c("Alta", "Baixa"))




# Ajustandp modelo Random Forest para Classificacao
set.seed(100)
modelo1 <- ranger::ranger(
  Produtividade ~ .,
  data = X,
  num.trees = Parm1$ntree,
  mtry = model1$bestTune$mtry,
  min.node.size = model1$bestTune$min.node.size,
  max.depth = Parm1$max_nodes,  
  importance = "permutation",
  probability = T,
  replace = TRUE,
  classification = TRUE,
  verbose = FALSE
)  


shap_1991_2019 <- simulacao_shap(modelo = modelo1, X = X, cultura = "Rice (1991-2019)",
               show_x_title = FALSE, sim_vector = 2000, tag = TRUE)


save(shap_1974_1990,shap_1991_2019,
     file = "C:/Users/jacim/Downloads/RData Shap artigo/Shap_Rice.RData")




