rm(list=ls())


# Bibliotecas
library(dplyr)
library(gridExtra)
library(ggplot2) 
library(readxl)
library(patchwork)

# carregando arquivo de dados no local do diretorio no r
#dados_soja <- load(choose.files()) # buscar arquivo de dados manualmente
dados_soja <- read_xlsx("Soja.xlsx", sheet = 1)
#View(dados_arroz) # visualizar dados

# funcao de filtragem descartara municipios com dados faltantes
linha_tem_ponto <- function(linha) {
  any(linha == "..." | linha =="-")
}

# Obtendo as posições das linhas onde pelo menos um elemento é "..."
posicoes_linhas <- which(apply(dados_soja, 1, linha_tem_ponto))

# total de municipios selecionados
abs(length(posicoes_linhas)- (dim(dados_soja)[1]-1))

# atualizando matriz de dados e realiando a transporta 
dados1 <- t(dados_soja[-posicoes_linhas,])

# Selecionando intervalo de Rendimento medio de interesse
# indo de 1975-2020 que sao as colheitas finais  
M_soja <- dados1[-c(1,2,49,50),-1]
colnames(M_soja) <- dados1[1,-1]
colnames(M_soja) <- gsub(" \\(RS\\)", "", colnames(M_soja)) # retirando (RG)

M_soja <- apply(M_soja, c(1, 2), as.numeric)
typeof(M_soja[1,1])

# numero de municipio
n_m = ncol(M_soja)

# Ajustar o modelo LOESS para cada coluna de M_arroz
prev <- function(M) {
  p <- matrix(NA, nrow = 46, ncol = n_m)
  
  for (i in 1:2) {
    for (k in 1:ncol(M)) {  # Percorre cada coluna de M_arroz
      # Selecionar os dados para o modelo LOESS com o número de elementos correto
      if (i == 1) {
        anos <- 1974:1990  # Para o período 1
        dados <- M[1:17, k]  # Seleciona as primeiras 17 linhas
        a <- loess(dados ~ anos)
        p[1:17, k] <- predict(a)
        
      } else {
        anos <- 1991:2019  # Para o período 2
        dados <- M[18:46, k]  # Seleciona as linhas de 18 a 46
        # Ajustar o modelo LOESS
        a <- loess(dados ~ anos)
        # Prever com o modelo ajustado e armazenar na matriz p
        p[18:46, k] <- predict(a)  
      }
    }
  }
  
  # Retornar as previsões
  return(as.data.frame(p))
}

# Aplicar a função
previsao <- prev(M_soja)

# calculo de desvio relativo
DR = matrix(NA, nrow = 46, ncol = n_m)
for (x in 1:n_m) {
  p2<- as.numeric(previsao[,x])
  
  DR[,x] <- (M_soja[, x] - p2) / p2
  
}

# funcao de excusao da formala de ajuste tecnologico dos dados
E <- function(RD,y){
  return(as.vector((RD+1)*y[length(y)]))
}

# realizando o ajuste tecnologico dos dados para o ano mais atual
RA <- matrix(NA, nrow = 46, ncol = n_m)

p01 <- c(1,18)
p02 <- c(17,46)

for(j in 1:2){
  for(i in 1:dim(M_soja)[2]){
    a <- E(RD = DR[p01[j]:p02[j],i],y =previsao[p01[j]:p02[j],i])
    RA[p01[j]:p02[j],i] <- a  
  }}
# nomenado coluna de matriz
colnames(RA) <- gsub(" ", "_",gsub(" \\(RS\\)", "", colnames(M_soja)))


# Funcao para gerar as figuras do ajuste de rendimento
G <- function(R, DR, RA, VP, nomes) {
  
  Periodo_1 <- 1974:1990
  Periodo_2 <- 1991:2019
  
  grafico_A <- ggplot(data = NULL, aes(x = Periodo_1)) +
    geom_point(aes(y = R[1:17]), color = "black") +  
    scale_y_continuous(limits = c(0,5000), breaks = seq(0,5000, 500)) +
    geom_line(aes(y = VP[1:17]), color = "blue", linewidth = 1) +
    scale_x_continuous(breaks = seq(1974, 1990, 1), labels = seq(1974,1990, 1)) +
    labs(x = "Year", y = "Soy Yield (kg ha⁻¹)", title = paste0(nomes," (1974-1990)"), tag = "A)") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          plot.tag = element_text(size = 10, face = "bold")) # Aqui o tamanho da tag é alterado para 8
  
  grafico_B <- ggplot(data = NULL, aes(x = Periodo_2)) +
    geom_point(aes(y = R[18:46]), color = "black") +  
    scale_y_continuous(limits = c(0,5000), breaks = seq(0,5000,500)) +
    geom_line(aes(y = VP[18:46]), color = "blue", linewidth = 1) +
    scale_x_continuous(breaks = seq(1991, 2019, 2), labels = seq(1991, 2019, 2)) +
    labs(x = "Year", y = "Soy Yield (kg ha⁻¹)", title = paste0(nomes," (1991-2019)"), tag = "D)") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          plot.tag = element_text(size = 10, face = "bold")) # Aqui o tamanho da tag é alterado para 8
  
  grafico_C <- ggplot(data = NULL, aes(x = Periodo_1)) +
    geom_point(aes(y = DR[1:17]), color = "black") +
    scale_x_continuous(breaks = seq(1974,1990, 1), labels = seq(1974, 1990, 1)) +
    labs(x = "Year", y = "Relative Deviation (kg ha⁻¹)", title = "Relative Deviation (1974-1990)", tag ="B)") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          plot.tag = element_text(size = 10, face = "bold")) # Aqui o tamanho da tag é alterado para 8
  
  # Gráfico D
  grafico_D <- ggplot(data = NULL, aes(x = Periodo_2)) +
    geom_point(aes(y = DR[18:46]), color = "black") +
    scale_x_continuous(breaks = seq(1991, 2019, 2), labels = seq(1991,2019, 2)) +
    labs(x = "Year", y = "Relative Deviation (kg ha⁻¹)", title = "Relative Deviation (1991-2019)", tag = "E)") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          plot.tag = element_text(size = 10, face = "bold")) # Aqui o tamanho da tag é alterado para 8
  
  # Gráfico E
  grafico_E <- ggplot(data = NULL, aes(x = Periodo_1)) +
    geom_point(aes(y = RA[1:17]), color = "black") +
    scale_x_continuous(breaks = seq(1974, 1990, 1), labels = seq(1974,1990, 1)) +
    scale_y_continuous(limits= c(0,5000), breaks = seq(0, 5000,500)) +
    labs(x = "Year", y = "Yield without Technological Effect (kg ha⁻¹)", title = "Yield without Tech Effect (1974-1990)", tag = "C)") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          plot.tag = element_text(size = 10, face = "bold")) # Aqui o tamanho da tag é alterado para 8
  
  # Gráfico F
  grafico_F <- ggplot(data = NULL, aes(x = Periodo_2)) +
    geom_point(aes(y = RA[18:46]), color = "black") +
    scale_x_continuous(breaks = seq(1991, 2019, 2), labels = seq(1991, 2019, 2)) +
    scale_y_continuous(limits= c(0,5000), breaks = seq(0,5000,500)) +
    labs(x = "Year", y = "Yield without Technological Effect (kg ha⁻¹)", title = "Yield without Tech Effect (1991-2019)", tag = "F)") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          plot.tag = element_text(size = 10, face = "bold")) # Aqui o tamanho da tag é alterado para 8
  
  # Combinar os gráficos usando o patchwork
  combinacao <- grafico_A + grafico_B + grafico_C + grafico_D + grafico_E + grafico_F +
    plot_layout(nrow = 3)
  
  return(combinacao)
}

nomes <- colnames(RA)

# caso deseje guardar todos os graficos em um diretorio local realize o codigo abaixo 
# alterando apenas o endereco do local de armazenamento
{
  graficos <- list()
  # Abrir o dispositivo PDF
  pdf("C:/Users/jacim/Downloads/Plot_165_Municipality_Soy.pdf", width = 8.27, height = 11.69)
  
  # Loop para adicionar os gráficos um por um
  for(i in 12 ){
    a <- G(R = M_soja[,i],DR = as.numeric(DR[,i]),RA = RA[,i],VP = previsao[,i],nomes = nomes[i])
    graficos[[i]] <- a
  }
  # Fechar o dispositivo PDF
  dev.off()
  
}

# resultados da clusterizacao para identificacao de anos com determinado 
# tipo ENSO
load("clusterizacao_RG.RData")


# Beseado no Resultado do FANOVA
###-------------------------------------------------------------------------
###    PERIODO 1990 - 2019 ############
###-------------------------------------------------------------------------

# classificando os anos para o primeiro periodo com dados disponiveis de
# produtividade 1990  -2019

e11 <- E1[c(18:46)]

# resultado da temperatura maxima 

# como El Nino e igual a La Nina
grupo01 <- gsub("El Nino|La Nina","Tmax_EL_LA", e11)
grupo01 <- gsub("Neutro","Tmax_N",grupo01)

# Para temperatura minima
# todos se diferenciam entao

grupo02 <-  gsub("El Nino", "Tmin_EL", e11)
grupo02 <- gsub("La Nina","Tmin_LA",grupo02)
grupo02 <- gsub("Neutro","Tmin_N",grupo02)

# precipitacao

grupo03<- gsub("El Nino", "P_EL", e11)
grupo03 <- gsub("Neutro", "P_N", grupo03)
grupo03 <- gsub("La Nina", "P_LA", grupo03)

# dados de produtividade vindo do ajuste ambiental carregando anteriomente
rendimento_91_19 <- as.numeric(RA[18:46,])


#municipios

municipio <- rep(colnames(RA),each = 29)

# alocando os dados em um data frame
df1 <- data.frame(rendimento_91_19,Tmax=as.factor(grupo01),
                  Tmin=as.factor(grupo02),Precip=as.factor(grupo03),
                  m = as.factor(municipio))

# Exibir o DataFrame final 
head(df1)


## Local para salvar os dados 
#local <- "C:/Users/jacim/Downloads/Dados Rdata/soja165_RG.RData"
#save(df1,M_soja,file = local)
