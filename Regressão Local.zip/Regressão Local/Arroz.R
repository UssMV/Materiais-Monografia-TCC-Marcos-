rm(list=ls())


# Bibliotecas
library(dplyr)
library(gridExtra)
library(ggplot2) 
library(readxl)

# carregando arquivo de dados no local do diretorio no r
#dados_arroz <- load(choose.files()) # buscar arquivo de dados manualmente
dados_arroz <- read_xlsx("Arroz_com_casca.xlsx", sheet = 1)
#View(dados_arroz) # visualizar dados

# funcao de filtragem descartara municipios com dados faltantes
linha_tem_ponto <- function(linha) {
  any(linha == "..." | linha =="-")
}

# Obtendo as posições das linhas onde pelo menos um elemento é "..."
posicoes_linhas <- which(apply(dados_arroz, 1, linha_tem_ponto))

# total de municipios selecionados
abs(length(posicoes_linhas)- (dim(dados_arroz)[1]-1))

# atualizando matriz de dados e realiando a transporta 
dados1 <- t(dados_arroz[-posicoes_linhas,])

# Selecionando intervalo de Rendimento medio de interesse
# indo de 1975-2020 que sao as colheitas finais  
M_arroz <- dados1[-c(1,2,49,50),-1]
colnames(M_arroz) <- dados1[1,-1]
colnames(M_arroz) <- gsub(" \\(RS\\)", "", colnames(M_arroz)) # retirando (RG)

M_arroz <- apply(M_arroz, c(1, 2), as.numeric)
typeof(M_arroz[1,1])

# numero de municipio
n_m = ncol(M_arroz)

# Ajustar o modelo LOESS para cada coluna de M_arroz
prev <- function(M) {
  p <- matrix(NA, nrow = 46, ncol = n_m)
  
  for (i in 1:2) {
    for (k in 1:ncol(M)) {  # Percorre cada coluna de M_arroz
      # Selecionar os dados para o modelo LOESS com o número de elementos correto
      if (i == 1) {
        anos <- 1974:1990  # Para o período 1
        dados <- M[1:17, k]  # Seleciona as primeiras 17 linhas
        a <- loess(dados ~ anos)
        p[1:17, k] <- predict(a)
        
      } else {
        anos <- 1991:2019  # Para o período 2
        dados <- M[18:46, k]  # Seleciona as linhas de 18 a 46
        # Ajustar o modelo LOESS
        a <- loess(dados ~ anos)
        # Prever com o modelo ajustado e armazenar na matriz p
        p[18:46, k] <- predict(a)  
      }
    }
  }
  
  # Retornar as previsões
  return(as.data.frame(p))
}

# Aplicar a função
previsao <- prev(M_arroz)

# calculo de desvio relativo
DR = matrix(NA, nrow = 46, ncol = n_m)
for (x in 1:n_m) {
  p2<- as.numeric(previsao[,x])
  
  DR[,x] <- (M_arroz[, x] - p2) / p2
  
}

# funcao de excusao da formala de ajuste tecnologico dos dados
E <- function(RD,y){
  return(as.vector((RD+1)*y[length(y)]))
}

# realizando o ajuste tecnologico dos dados para o ano mais atual
RA <- matrix(NA, nrow = 46, ncol = n_m)

p01 <- c(1,18)
p02 <- c(17,46)

for(j in 1:2){
  for(i in 1:dim(M_arroz)[2]){
    a <- E(RD = DR[p01[j]:p02[j],i],y =previsao[p01[j]:p02[j],i])
    RA[p01[j]:p02[j],i] <- a  
  }}
# nomenado coluna de matriz
colnames(RA) <- gsub(" ", "_",gsub(" \\(RS\\)", "", colnames(M_arroz)))




# Função para plotar gráficos
G <- function(R, DR, RA, VP,nomes) {
  Periodo_1 <- 1974:1990
  Periodo_2 <- 1991:2019
  
  grafico <- ggplot(data = NULL, aes(x = Periodo_1)) +
    geom_point(aes(y = R[1:17]), color = "black") +  
    scale_y_continuous(limits = c(0,11000), breaks = seq(0, 11000, 1000),
                       label = function(x) paste0(x, "(kg/ha)")) +
    geom_line(aes(y = VP[1:17]), color = "blue", size = 1) +
    scale_x_continuous(breaks = seq(1974, 1990, 1), labels = seq(1974,1990, 1)) +
    labs(x = "Year", y = "Rice Yield", title = paste0("Rice Yield in ",nomes," (1974-1990)")) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  a <- ggplot(data = NULL, aes(x = Periodo_1)) +
    geom_point(aes(y = DR[1:17]), color = "black") +
    scale_x_continuous(breaks = seq(1974, 1990, 1), labels = seq(1974, 1990, 1)) +
    labs(x = "Year", y = "Relative Deviation") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1)) 
  
  a1 <- ggplot(data = NULL, aes(x = Periodo_1)) +
    geom_point(aes(y = RA[1:17]), color = "black") +
    scale_x_continuous(breaks = seq(1974, 1990, 1), labels = seq(1974,1990, 1)) +
    scale_y_continuous(limits= c(0,11000),breaks = seq(0, 11000, 1000)) +
    labs(x = "Year", y = "Yield without Technological Effect") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1)) 
  
  grafico1 <- ggplot(data = NULL, aes(x = Periodo_2)) +
    geom_point(aes(y = R[18:46], color = "Observações"), size = 4) +  
    geom_line(aes(y = VP[18:46], color = "Tendência Estimada"), size = 2) +
    scale_y_continuous(limits = c(0,11000), breaks = seq(0, 11000,1000)) +
    scale_x_continuous(breaks = seq(1991,2019,1), labels = seq(1991, 2019, 1)) +
    scale_color_manual(values = c("Observações" = "black", 
                                  "Tendência Estimada" = "blue")) +
    labs(x = "", y = "Rendimento do Arroz\n (Kg ha⁻¹)", 
         title = NULL,
         color = "") +  # Título vazio para a legenda
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1,size = 21, face = "bold"),
          legend.position = "bottom",
          legend.text = element_text(size = 20),
          axis.title.y = element_text(size = 20, face = "bold"),
          axis.text.y = element_text(size = 21, face = "bold"))
  
  a2 <- ggplot(data = NULL, aes(x = Periodo_2)) +
    geom_point(aes(y = DR[18:46]), color = "black") +
    scale_x_continuous(breaks = seq(1991, 2019, 2), labels = seq(1991,2019, 2)) +
    labs(x = "Year", y = "Relative Deviation") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1)) 
  
  a3 <- ggplot(data = NULL, aes(x = Periodo_2)) +
    geom_point(aes(y = RA[18:46]), color = "black", size = 4) +
    scale_x_continuous(breaks = seq(1991, 2019, 1), labels = seq(1991, 2019, 1)) +
    scale_y_continuous(limits= c(0,11000),breaks = seq(0,11000,1000)) +
    labs(x = "", y = "Rendimento sem Efeito\n Tecnológico (kg ha⁻¹)") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 21, face = "bold" ),
          axis.title.y = element_text(face = "bold",size = 20),
          axis.text.y = element_text(size = 21, face = "bold")) 
  
  lista <- list(
    plot_full = grid.arrange(grafico1,a2,a3, nrow = 3),
    Sem_tendecia = a3,
    estimacao = grafico1
    
  )
  
  #return(grid.arrange(grafico,grafico1, a, a2,a1,a3, nrow = 3))
  return(lista)
}

nomes <- colnames(RA)

# plotando apenas o muncípio Alegrete
i =2
Alegrete <- G(R = M_arroz[,i],DR = as.numeric(DR[,i]),RA = RA[,i],VP = previsao[,i],nomes = nomes[i])
Alegrete$Sem_tendecia

# caso deseje guardar todos os graficos em um diretorio local realize o codigo abaixo 
# alterando apenas o endereco do local de armazenamento
{
  graficos <- list()
  # Abrir o dispositivo PDF
  pdf("C:/Users/jacim/Downloads/Plot_68_Municipality_Rice.pdf", width = 8.27, height = 11.69)
  
  # Loop para adicionar os gráficos um por um
  for(i in 1:ncol(RA)){
    a <- G(R = M_arroz[,i],DR = as.numeric(DR[,i]),RA = RA[,i],VP = previsao[,i],nomes = nomes[i])
    graficos[[i]] <- a
  }
  # Fechar o dispositivo PDF
  dev.off()
  
}


# resultados da clusterizacao para identificacao de anos com determinado 
# tipo ENSO
load("clusterizacao_RG.RData")

# Beseado no Resultado do FANOVA
###-------------------------------------------------------------------------
###    PERIODO 1990 - 2019 ############
###-------------------------------------------------------------------------

# classificando os anos para o primeiro periodo com dados disponiveis de
# produtividade 1990  -2019

e11 <- E1[c(18:46)]


# resultado da temperatura maxima no primeiro periodo

# como El Nino e igual a La Nina
grupo01 <- gsub("El Nino|La Nina","Tmax_EL_LA", e11)
grupo01 <- gsub("Neutro","Tmax_N",grupo01)

# Para temperatura minima
# todos se diferenciam entao

grupo02 <-  gsub("El Nino", "Tmin_EL", e11)
grupo02 <- gsub("La Nina","Tmin_LA",grupo02)
grupo02 <- gsub("Neutro","Tmin_N",grupo02)

# precipitacao

grupo03<- gsub("El Nino", "P_EL", e11)
grupo03 <- gsub("Neutro", "P_N", grupo03)
grupo03 <- gsub("La Nina", "P_LA", grupo03)

# dados de produtividade vindo do ajuste ambiental carregando anteriomente
rendimento_91_19 <- as.numeric(RA[18:46,])

municipio <- rep(colnames(RA),each = 29)

# alocando os dados em um data frame
df1 <- data.frame(rendimento_91_19,Tmax=as.factor(grupo01),
                  Tmin=as.factor(grupo02),Precip=as.factor(grupo03),
                  m = as.factor(municipio))


# Quandidade de fenomeno em cada ciclo final
fenomeno <- unique(resultado)

# Definindo os nomes dos fenômenos
fenomenos <- unique(resultado)

# Criando um fator que associa os anos aos fenômenos
fator <- factor(resultado[30:58], levels = fenomenos)

# Usando split para dividir os anos conforme o fenômeno
Grupos_1991_2019 <- split(1991:2019, fator)
Grupos_1991_2019


## Local para salvar os dados 
#local <- "C:/Users/jacim/Downloads/Dados Rdata/Arroz68_RG.RData"
#save(df,df1,M_arroz,file = local)
